package com.raven.service;

import com.raven.connection.DatabaseConnection;
import com.raven.model.Model_Client;
import com.raven.model.Model_Login;
import com.raven.model.Model_Message;
import com.raven.model.Model_Register;
import com.raven.model.Model_User_Account;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ServiceUser {

    public ServiceUser() {
        this.con = DatabaseConnection.getInstance().getConnection();
    }

    public Model_Message register(Model_Register data) {
        Model_Message message = new Model_Message();
        String checkUserQuery = CHECK_USER;
        String insertUserQuery = INSERT_USER;
        String insertUserAccountQuery = INSERT_USER_ACCOUNT;

        try (PreparedStatement checkStmt = con.prepareStatement(checkUserQuery);
             PreparedStatement insertUserStmt = con.prepareStatement(insertUserQuery, PreparedStatement.RETURN_GENERATED_KEYS);
             PreparedStatement insertUserAccountStmt = con.prepareStatement(insertUserAccountQuery)) {

            // Check if user already exists
            checkStmt.setString(1, data.getUserName());
            try (ResultSet rs = checkStmt.executeQuery()) {
                if (rs.next()) {
                    message.setAction(false);
                    message.setMessage("User Already Exists");
                    return message;
                }
            }

            // Insert new user
            con.setAutoCommit(false);
            insertUserStmt.setString(1, data.getUserName());
            insertUserStmt.setString(2, data.getPassword());
            insertUserStmt.executeUpdate();

            // Get generated userID
            int userID;
            try (ResultSet generatedKeys = insertUserStmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    userID = generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating user failed, no ID obtained.");
                }
            }

            // Insert user account
            insertUserAccountStmt.setInt(1, userID);
            insertUserAccountStmt.setString(2, data.getUserName());
            insertUserAccountStmt.executeUpdate();

            con.commit();
            message.setAction(true);
            message.setMessage("Ok");
            message.setData(new Model_User_Account(userID, data.getUserName(), "", "", true));

        } catch (SQLException e) {
            message.setAction(false);
            message.setMessage("Server Error: " + e.getMessage());
            try {
                if (!con.getAutoCommit()) {
                    con.rollback();
                }
            } catch (SQLException rollbackEx) {
                message.setMessage("Rollback failed: " + rollbackEx.getMessage());
            }
        } finally {
            try {
                if (con != null && !con.getAutoCommit()) {
                    con.setAutoCommit(true);
                }
            } catch (SQLException e) {
                // Log and handle auto-commit reset failure
            }
        }
        return message;
    }

    public Model_User_Account login(Model_Login login) {
        Model_User_Account data = null;
        String loginQuery = LOGIN;

        try (PreparedStatement loginStmt = con.prepareStatement(loginQuery, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY)) {

            loginStmt.setString(1, login.getUserName());
            loginStmt.setString(2, login.getPassword());

            try (ResultSet rs = loginStmt.executeQuery()) {
                if (rs.next()) {
                    int userID = rs.getInt("UserID");
                    String userName = rs.getString("UserName");
                    String gender = rs.getString("Gender");
                    String image = rs.getString("ImageString");
                    data = new Model_User_Account(userID, userName, gender, image, true);
                }
            }
        } catch (SQLException e) {
            // Log and handle SQL exceptions
            e.printStackTrace();
        }
        return data;
    }

    public List<Model_User_Account> getUser(int exitUser) {
        List<Model_User_Account> list = new ArrayList<>();
        String selectUserAccountQuery = SELECT_USER_ACCOUNT;

        try (PreparedStatement selectStmt = con.prepareStatement(selectUserAccountQuery)) {
            selectStmt.setInt(1, exitUser);

            try (ResultSet rs = selectStmt.executeQuery()) {
                while (rs.next()) {
                    int userID = rs.getInt("UserID");
                    String userName = rs.getString("UserName");
                    String gender = rs.getString("Gender");
                    String image = rs.getString("ImageString");
                    list.add(new Model_User_Account(userID, userName, gender, image, checkUserStatus(userID)));
                }
            }
        } catch (SQLException e) {
            // Log and handle SQL exceptions
            e.printStackTrace();
        }
        return list;
    }

    private boolean checkUserStatus(int userID) {
        List<Model_Client> clients = Service.getInstance(null).getListClient();
        return clients.stream().anyMatch(c -> c.getUser().getUserID() == userID);
    }

    // SQL Queries
    private static final String LOGIN = "SELECT UserID, user_account.UserName, Gender, ImageString FROM `user` JOIN user_account USING (UserID) WHERE `user`.UserName=BINARY(?) AND `user`.`Password`=BINARY(?) AND user_account.`Status`='1'";
    private static final String SELECT_USER_ACCOUNT = "SELECT UserID, UserName, Gender, ImageString FROM user_account WHERE user_account.`Status`='1' AND UserID<>?";
    private static final String INSERT_USER = "INSERT INTO user (UserName, `Password`) VALUES (?, ?)";
    private static final String INSERT_USER_ACCOUNT = "INSERT INTO user_account (UserID, UserName) VALUES (?, ?)";
    private static final String CHECK_USER = "SELECT UserID FROM user WHERE UserName = ? LIMIT 1";
    
    // Instance
    private final Connection con;
}